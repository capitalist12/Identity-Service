package com.demo.identity_service.enums;

public enum Role {
    ADMIN,
    USER
}
